Place these folders in your library directory.

Credit:
https://github.com/adafruit/Adafruit_BME280_Library
https://github.com/adafruit/Adafruit_Sensor
https://github.com/ERROPiX/ESP32_AnalogWrite
https://github.com/madhephaestus/ESP32Servo
https://github.com/timum-viw/socket.io-client
https://github.com/sparkfun/SparkFun_Ambient_Light_Sensor_Arduino_Library