# IoT-project

The project prototype contains three folders, one folder for the server, client and webpage respectively. Each folder contains another README with further instructions as to how it works. Read report (in Norwegian) for more detailed description.
